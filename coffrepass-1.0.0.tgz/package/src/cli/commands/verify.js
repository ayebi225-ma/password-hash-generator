import pc from 'picocolors';
import { verifyDetailed } from '../../core/verify/index.js';
import { getSecretInput } from '../ui/prompts.js';
import { outputResult, printSuccess, printError, handleCommandError } from '../ui/formatters.js';
import { EXIT_CODES } from '../ui/exit-codes.js';

export async function verifyCommand(arg1, arg2, options) {
  try {
    let secretArg;
    let hashString;

    if (arg2) {
      secretArg = arg1;
      hashString = arg2;
    } else if (arg1) {
      // Single argument passed: treat as hash, prompt for secret
      hashString = arg1;
    } else {
      printError('Hash string is required for verification: coffrepass verify [secret] <hash>');
      process.exit(EXIT_CODES.INVALID_USAGE);
    }

    const secret = await getSecretInput(secretArg, {
      message: 'Enter secret to verify against hash (masked):',
    });

    const result = await verifyDetailed(secret, hashString);

    outputResult(result, options.json, () => {
      console.log();
      if (result.valid) {
        printSuccess(`Password MATCHES hash (${pc.cyan(result.algorithm)})`);
        console.log(`  ${pc.dim('Execution time:')} ${result.executionTimeMs} ms`);
      } else {
        printError(`Password DOES NOT MATCH hash`);
        if (result.algorithm !== 'unknown') {
          console.log(`  ${pc.dim('Algorithm detected:')} ${result.algorithm}`);
        }
      }
      console.log();
    });

    process.exit(result.valid ? EXIT_CODES.SUCCESS : EXIT_CODES.VERIFY_MISMATCH);
  } catch (err) {
    handleCommandError(err, options.json);
    process.exit(EXIT_CODES.GENERAL_ERROR);
  }
}
